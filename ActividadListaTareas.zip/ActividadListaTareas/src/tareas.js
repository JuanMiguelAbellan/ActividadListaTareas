import { get } from "./peticiones.js";
import { pintarTareas, añadirTarea } from "./utilidadesTareas.js";

document.addEventListener("DOMContentLoaded", listeners)

function listeners(){
    let logOut = document.querySelector("#btnLogout")
    logOut.addEventListener("click", ()=>{
        sessionStorage.removeItem("id")
        window.location.assign("./index.html")
    })

    let butAñadir = document.querySelector("#btnAddTask")
    butAñadir.addEventListener("click", añadirTarea)

    get("/tareas?id_user="+sessionStorage.getItem("id"), pintarTareas, (error)=>{console.log(error)})
}